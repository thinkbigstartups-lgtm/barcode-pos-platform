// POS System Data and State Management
class POSSystem {
    constructor() {
        this.products = [
            {"id": "p001", "name": "Basmati Rice 5kg", "barcode": "8901030875472", "price": 450, "category": "Groceries", "gstRate": 5, "stock": 25, "unit": "kg", "image": "🌾"},
            {"id": "p002", "name": "Refined Sunflower Oil 1L", "barcode": "8901030875489", "price": 120, "category": "Groceries", "gstRate": 5, "stock": 40, "unit": "L", "image": "🛢️"},
            {"id": "p003", "name": "Samsung Galaxy A54", "barcode": "8801643708447", "price": 25000, "category": "Electronics", "gstRate": 18, "stock": 8, "unit": "pcs", "image": "📱"},
            {"id": "p004", "name": "Sony WH-CH720N Headphones", "barcode": "4548736142538", "price": 8500, "category": "Electronics", "gstRate": 18, "stock": 12, "unit": "pcs", "image": "🎧"},
            {"id": "p005", "name": "Men's Cotton Shirt", "barcode": "5901234123457", "price": 899, "category": "Clothing", "gstRate": 12, "stock": 20, "unit": "pcs", "image": "👔"},
            {"id": "p006", "name": "Levi's Jeans", "barcode": "5901234123464", "price": 2499, "category": "Clothing", "gstRate": 12, "stock": 15, "unit": "pcs", "image": "👖"},
            {"id": "p007", "name": "Colgate Toothpaste 200g", "barcode": "8901030875496", "price": 85, "category": "Personal Care", "gstRate": 18, "stock": 50, "unit": "pcs", "image": "🦷"},
            {"id": "p008", "name": "Surf Excel Detergent 1kg", "barcode": "8901030875502", "price": 165, "category": "Household", "gstRate": 18, "stock": 30, "unit": "kg", "image": "🧽"},
            {"id": "p009", "name": "Amul Fresh Milk 1L", "barcode": "8901030875519", "price": 62, "category": "Dairy", "gstRate": 5, "stock": 35, "unit": "L", "image": "🥛"},
            {"id": "p010", "name": "Britannia Bread 400g", "barcode": "8901030875526", "price": 25, "category": "Bakery", "gstRate": 5, "stock": 45, "unit": "pcs", "image": "🍞"},
            {"id": "p011", "name": "Apple iPhone Cable", "barcode": "1901030875533", "price": 1200, "category": "Electronics", "gstRate": 18, "stock": 25, "unit": "pcs", "image": "🔌"},
            {"id": "p012", "name": "Nike Running Shoes", "barcode": "1234567890128", "price": 4500, "category": "Footwear", "gstRate": 12, "stock": 10, "unit": "pair", "image": "👟"},
            {"id": "p013", "name": "Himalaya Face Wash", "barcode": "8901030875540", "price": 125, "category": "Personal Care", "gstRate": 18, "stock": 40, "unit": "pcs", "image": "🧴"},
            {"id": "p014", "name": "Maggi Noodles 70g", "barcode": "8901030875557", "price": 14, "category": "Snacks", "gstRate": 12, "stock": 60, "unit": "pcs", "image": "🍜"},
            {"id": "p015", "name": "Tata Salt 1kg", "barcode": "8901030875564", "price": 22, "category": "Groceries", "gstRate": 5, "stock": 55, "unit": "kg", "image": "🧂"},
            {"id": "p016", "name": "Red Bull Energy Drink", "barcode": "9002490100026", "price": 125, "category": "Beverages", "gstRate": 28, "stock": 24, "unit": "can", "image": "🥤"},
            {"id": "p017", "name": "Dove Soap 100g", "barcode": "8901030875571", "price": 42, "category": "Personal Care", "gstRate": 18, "stock": 48, "unit": "pcs", "image": "🧼"},
            {"id": "p018", "name": "Fortune Soybean Oil 1L", "barcode": "8901030875588", "price": 135, "category": "Groceries", "gstRate": 5, "stock": 32, "unit": "L", "image": "🛢️"},
            {"id": "p019", "name": "Haldiram's Bhujia 200g", "barcode": "8901030875595", "price": 45, "category": "Snacks", "gstRate": 12, "stock": 38, "unit": "pcs", "image": "🥜"},
            {"id": "p020", "name": "Patanjali Honey 500g", "barcode": "8901030875601", "price": 185, "category": "Organic", "gstRate": 5, "stock": 20, "unit": "jar", "image": "🍯"},
            {"id": "p021", "name": "OnePlus Type-C Cable", "barcode": "6921815613824", "price": 899, "category": "Electronics", "gstRate": 18, "stock": 18, "unit": "pcs", "image": "🔌"},
            {"id": "p022", "name": "Lakme Lipstick", "barcode": "8901030875618", "price": 450, "category": "Cosmetics", "gstRate": 18, "stock": 22, "unit": "pcs", "image": "💄"},
            {"id": "p023", "name": "Parle-G Biscuits 800g", "barcode": "8901030875625", "price": 35, "category": "Snacks", "gstRate": 12, "stock": 42, "unit": "pack", "image": "🍪"},
            {"id": "p024", "name": "Rin Detergent Bar 250g", "barcode": "8901030875632", "price": 28, "category": "Household", "gstRate": 18, "stock": 35, "unit": "bar", "image": "🧽"},
            {"id": "p025", "name": "Cadbury Dairy Milk 55g", "barcode": "7622210951267", "price": 35, "category": "Confectionery", "gstRate": 18, "stock": 65, "unit": "bar", "image": "🍫"}
        ];

        this.gstRates = {
            "5": {"cgst": 2.5, "sgst": 2.5, "igst": 5},
            "12": {"cgst": 6, "sgst": 6, "igst": 12},
            "18": {"cgst": 9, "sgst": 9, "igst": 18},
            "28": {"cgst": 14, "sgst": 14, "igst": 28}
        };

        this.businessInfo = {
            "name": "RetailMax POS System",
            "address": "123 Shopping Complex, Main Market",
            "city": "New Delhi",
            "state": "Delhi",
            "pincode": "110001",
            "gstin": "07AAACH7409R1ZZ",
            "phone": "+91 98765 43210"
        };

        this.cart = [];
        this.transactions = [];
        this.customers = [];
        this.currentInvoiceNumber = 1001;
        this.camera = null;
        this.isIntrastate = true;

        this.init();
    }

    init() {
        this.bindEvents();
        this.updateInvoiceNumber();
        this.updateCartDisplay();
        this.loadCategories();
    }

    // Event Binding
    bindEvents() {
        // Barcode input
        const barcodeInput = document.getElementById('barcodeInput');
        if (barcodeInput) {
            barcodeInput.addEventListener('input', (e) => {
                if (e.target.value.length >= 8) {
                    this.scanBarcode(e.target.value.trim());
                    e.target.value = '';
                }
            });

            // Also trigger on Enter key
            barcodeInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter' && e.target.value.trim().length >= 8) {
                    this.scanBarcode(e.target.value.trim());
                    e.target.value = '';
                }
            });
        }

        // Camera button
        const cameraBtn = document.getElementById('cameraBtn');
        if (cameraBtn) {
            cameraBtn.addEventListener('click', () => {
                this.openCamera();
            });
        }

        // Manual add button
        const manualAddBtn = document.getElementById('manualAddBtn');
        if (manualAddBtn) {
            manualAddBtn.addEventListener('click', () => {
                this.openManualAddModal();
            });
        }

        // Product search
        const productSearch = document.getElementById('productSearch');
        if (productSearch) {
            productSearch.addEventListener('input', (e) => {
                this.searchProducts(e.target.value);
            });
        }

        // Category buttons
        document.querySelectorAll('.category-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.filterByCategory(e.target.dataset.category);
                document.querySelectorAll('.category-btn').forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
            });
        });

        // Payment method change
        document.querySelectorAll('input[name="paymentMethod"]').forEach(radio => {
            radio.addEventListener('change', () => {
                this.updatePaymentMethod();
            });
        });

        // Received amount input
        const receivedAmount = document.getElementById('receivedAmount');
        if (receivedAmount) {
            receivedAmount.addEventListener('input', () => {
                this.calculateChange();
            });
        }

        // State selection
        const stateSelect = document.getElementById('stateSelect');
        if (stateSelect) {
            stateSelect.addEventListener('change', (e) => {
                this.isIntrastate = e.target.value === 'delhi';
                this.updateCartDisplay();
            });
        }

        // Action buttons
        const clearCartBtn = document.getElementById('clearCartBtn');
        if (clearCartBtn) {
            clearCartBtn.addEventListener('click', () => {
                this.clearCart();
            });
        }

        const processPaymentBtn = document.getElementById('processPaymentBtn');
        if (processPaymentBtn) {
            processPaymentBtn.addEventListener('click', () => {
                this.processPayment();
            });
        }

        const holdBillBtn = document.getElementById('holdBillBtn');
        if (holdBillBtn) {
            holdBillBtn.addEventListener('click', () => {
                this.holdBill();
            });
        }

        // Modal close buttons
        document.querySelectorAll('.modal-close').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const modal = e.target.closest('.modal');
                if (modal) {
                    modal.classList.add('hidden');
                    if (modal.id === 'cameraModal') {
                        this.stopCamera();
                    }
                }
            });
        });

        // Close modal when clicking outside
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    modal.classList.add('hidden');
                    if (modal.id === 'cameraModal') {
                        this.stopCamera();
                    }
                }
            });
        });

        // Manual add product
        const addManualProductBtn = document.getElementById('addManualProductBtn');
        if (addManualProductBtn) {
            addManualProductBtn.addEventListener('click', () => {
                this.addManualProduct();
            });
        }

        // Print invoice
        const printInvoiceBtn = document.getElementById('printInvoiceBtn');
        if (printInvoiceBtn) {
            printInvoiceBtn.addEventListener('click', () => {
                window.print();
            });
        }

        // Reports and other features
        const reportsBtn = document.getElementById('reportsBtn');
        if (reportsBtn) {
            reportsBtn.addEventListener('click', () => {
                this.showReports();
            });
        }

        const inventoryBtn = document.getElementById('inventoryBtn');
        if (inventoryBtn) {
            inventoryBtn.addEventListener('click', () => {
                this.showInventory();
            });
        }

        const lastInvoiceBtn = document.getElementById('lastInvoiceBtn');
        if (lastInvoiceBtn) {
            lastInvoiceBtn.addEventListener('click', () => {
                this.showLastInvoice();
            });
        }

        const dailySalesBtn = document.getElementById('dailySalesBtn');
        if (dailySalesBtn) {
            dailySalesBtn.addEventListener('click', () => {
                this.showDailySales();
            });
        }

        // Initialize payment method
        this.updatePaymentMethod();
    }

    // Barcode Scanning
    scanBarcode(barcode) {
        console.log('Scanning barcode:', barcode);
        const product = this.products.find(p => p.barcode === barcode);
        if (product) {
            this.addToCart(product);
            this.showToast(`Added ${product.name} to cart`);
        } else {
            this.showToast('Product not found', 'error');
        }
    }

    // Camera Functions
    async openCamera() {
        const modal = document.getElementById('cameraModal');
        const video = document.getElementById('cameraVideo');
        
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ 
                video: { facingMode: 'environment' } 
            });
            video.srcObject = stream;
            this.camera = stream;
            modal.classList.remove('hidden');

            // Simulate barcode detection after 3 seconds for demo
            setTimeout(() => {
                this.simulateBarcodeDetection();
            }, 3000);
        } catch (error) {
            console.error('Camera access error:', error);
            // For demo purposes, simulate camera scanning
            modal.classList.remove('hidden');
            setTimeout(() => {
                this.simulateBarcodeDetection();
            }, 3000);
        }
    }

    simulateBarcodeDetection() {
        // For demo purposes, randomly select a barcode
        const randomProduct = this.products[Math.floor(Math.random() * this.products.length)];
        this.scanBarcode(randomProduct.barcode);
        const modal = document.getElementById('cameraModal');
        if (modal) {
            modal.classList.add('hidden');
        }
        this.stopCamera();
    }

    stopCamera() {
        if (this.camera) {
            this.camera.getTracks().forEach(track => track.stop());
            this.camera = null;
        }
    }

    // Cart Management
    addToCart(product, quantity = 1) {
        if (product.stock < quantity) {
            this.showToast(`Insufficient stock for ${product.name}`, 'error');
            return;
        }

        const existingItem = this.cart.find(item => item.id === product.id);
        if (existingItem) {
            existingItem.quantity += quantity;
            existingItem.totalPrice = existingItem.price * existingItem.quantity;
        } else {
            this.cart.push({
                ...product,
                quantity: quantity,
                totalPrice: product.price * quantity
            });
        }

        // Update product stock
        product.stock -= quantity;
        this.updateCartDisplay();
        this.updateProcessButton();
    }

    removeFromCart(productId) {
        const itemIndex = this.cart.findIndex(item => item.id === productId);
        if (itemIndex !== -1) {
            const item = this.cart[itemIndex];
            // Restore stock
            const product = this.products.find(p => p.id === productId);
            if (product) {
                product.stock += item.quantity;
            }
            this.cart.splice(itemIndex, 1);
            this.updateCartDisplay();
            this.updateProcessButton();
        }
    }

    updateQuantity(productId, newQuantity) {
        const item = this.cart.find(item => item.id === productId);
        const product = this.products.find(p => p.id === productId);
        
        if (item && product && newQuantity > 0) {
            const difference = newQuantity - item.quantity;
            
            if (product.stock >= difference) {
                product.stock -= difference;
                item.quantity = newQuantity;
                item.totalPrice = item.price * newQuantity;
                this.updateCartDisplay();
            } else {
                this.showToast('Insufficient stock', 'error');
            }
        } else if (newQuantity === 0) {
            this.removeFromCart(productId);
        }
    }

    clearCart() {
        // Restore stock for all items
        this.cart.forEach(item => {
            const product = this.products.find(p => p.id === item.id);
            if (product) {
                product.stock += item.quantity;
            }
        });
        
        this.cart = [];
        this.updateCartDisplay();
        this.updateProcessButton();
        this.showToast('Cart cleared');
    }

    // Display Updates
    updateCartDisplay() {
        const cartItems = document.getElementById('cartItems');
        
        if (!cartItems) return;
        
        if (this.cart.length === 0) {
            cartItems.innerHTML = '<div class="empty-cart"><p>No items in cart. Scan or search products to add.</p></div>';
        } else {
            cartItems.innerHTML = this.cart.map(item => `
                <div class="cart-item">
                    <div class="cart-item-image">${item.image}</div>
                    <div class="cart-item-details">
                        <h4>${item.name}</h4>
                        <div class="cart-item-meta">
                            GST: ${item.gstRate}% | ${item.unit}
                            <span class="stock-status ${item.stock < 5 ? 'low' : 'good'}">
                                Stock: ${item.stock}
                            </span>
                        </div>
                    </div>
                    <div class="cart-item-price">
                        <span class="unit-price">₹${item.price}/${item.unit}</span>
                        <span class="total-price">₹${item.totalPrice.toFixed(2)}</span>
                    </div>
                    <div class="quantity-controls">
                        <button class="quantity-btn" onclick="pos.updateQuantity('${item.id}', ${item.quantity - 1})">-</button>
                        <input type="number" class="quantity-input" value="${item.quantity}" 
                               onchange="pos.updateQuantity('${item.id}', parseInt(this.value) || 0)">
                        <button class="quantity-btn" onclick="pos.updateQuantity('${item.id}', ${item.quantity + 1})">+</button>
                    </div>
                    <button class="remove-item" onclick="pos.removeFromCart('${item.id}')">×</button>
                </div>
            `).join('');
        }

        this.updateCartSummary();
    }

    updateCartSummary() {
        const subtotal = this.cart.reduce((sum, item) => sum + item.totalPrice, 0);
        const gstCalculation = this.calculateGST(subtotal);
        const total = subtotal + gstCalculation.totalGst;

        const subtotalEl = document.getElementById('subtotal');
        const totalAmountEl = document.getElementById('totalAmount');
        
        if (subtotalEl) subtotalEl.textContent = `₹${subtotal.toFixed(2)}`;
        if (totalAmountEl) totalAmountEl.textContent = `₹${total.toFixed(2)}`;

        // Update GST breakdown
        const gstBreakdown = document.getElementById('gstBreakdown');
        if (gstBreakdown) {
            if (this.isIntrastate) {
                gstBreakdown.innerHTML = `
                    <div class="summary-row gst-row">
                        <span>CGST:</span>
                        <span id="cgstAmount">₹${gstCalculation.cgst.toFixed(2)}</span>
                    </div>
                    <div class="summary-row gst-row">
                        <span>SGST:</span>
                        <span id="sgstAmount">₹${gstCalculation.sgst.toFixed(2)}</span>
                    </div>
                `;
            } else {
                gstBreakdown.innerHTML = `
                    <div class="summary-row gst-row">
                        <span>IGST:</span>
                        <span id="igstAmount">₹${gstCalculation.igst.toFixed(2)}</span>
                    </div>
                `;
            }
        }
    }

    calculateGST(subtotal) {
        let cgst = 0, sgst = 0, igst = 0;

        this.cart.forEach(item => {
            const itemSubtotal = item.totalPrice;
            const gstRate = this.gstRates[item.gstRate.toString()];
            
            if (this.isIntrastate) {
                cgst += (itemSubtotal * gstRate.cgst) / 100;
                sgst += (itemSubtotal * gstRate.sgst) / 100;
            } else {
                igst += (itemSubtotal * gstRate.igst) / 100;
            }
        });

        return {
            cgst,
            sgst,
            igst,
            totalGst: cgst + sgst + igst
        };
    }

    // Search and Filter
    searchProducts(query) {
        const results = document.getElementById('searchResults');
        
        if (!results || query.length < 2) {
            if (results) results.innerHTML = '';
            return;
        }

        const filteredProducts = this.products.filter(product =>
            product.name.toLowerCase().includes(query.toLowerCase()) ||
            product.category.toLowerCase().includes(query.toLowerCase())
        );

        results.innerHTML = filteredProducts.slice(0, 5).map(product => `
            <div class="search-item" onclick="pos.addToCart(pos.products.find(p => p.id === '${product.id}'))">
                <div class="search-item-name">${product.image} ${product.name}</div>
                <div class="search-item-details">
                    <span>₹${product.price}</span>
                    <span>Stock: ${product.stock}</span>
                </div>
            </div>
        `).join('');
    }

    filterByCategory(category) {
        const results = document.getElementById('searchResults');
        
        if (!results) return;
        
        if (category === 'all') {
            results.innerHTML = '';
            return;
        }

        const filteredProducts = this.products.filter(product =>
            product.category === category
        );

        results.innerHTML = filteredProducts.slice(0, 8).map(product => `
            <div class="search-item" onclick="pos.addToCart(pos.products.find(p => p.id === '${product.id}'))">
                <div class="search-item-name">${product.image} ${product.name}</div>
                <div class="search-item-details">
                    <span>₹${product.price}</span>
                    <span>Stock: ${product.stock}</span>
                </div>
            </div>
        `).join('');
    }

    loadCategories() {
        // Categories are already hardcoded in HTML for simplicity
    }

    // Payment Processing
    updatePaymentMethod() {
        const paymentMethod = document.querySelector('input[name="paymentMethod"]:checked')?.value || 'cash';
        const cashCalculator = document.getElementById('cashCalculator');
        
        if (cashCalculator) {
            if (paymentMethod === 'cash') {
                cashCalculator.style.display = 'block';
            } else {
                cashCalculator.style.display = 'none';
            }
        }
    }

    calculateChange() {
        const total = this.cart.reduce((sum, item) => sum + item.totalPrice, 0);
        const gstCalculation = this.calculateGST(total);
        const finalTotal = total + gstCalculation.totalGst;
        const received = parseFloat(document.getElementById('receivedAmount')?.value) || 0;
        const change = received - finalTotal;

        const changeAmountEl = document.getElementById('changeAmount');
        if (changeAmountEl) {
            changeAmountEl.textContent = `₹${change >= 0 ? change.toFixed(2) : '0.00'}`;
        }
    }

    updateProcessButton() {
        const processBtn = document.getElementById('processPaymentBtn');
        if (processBtn) {
            processBtn.disabled = this.cart.length === 0;
        }
    }

    processPayment() {
        if (this.cart.length === 0) return;

        const paymentMethod = document.querySelector('input[name="paymentMethod"]:checked')?.value || 'cash';
        const subtotal = this.cart.reduce((sum, item) => sum + item.totalPrice, 0);
        const gstCalculation = this.calculateGST(subtotal);
        const total = subtotal + gstCalculation.totalGst;

        // Validate payment for cash
        if (paymentMethod === 'cash') {
            const received = parseFloat(document.getElementById('receivedAmount')?.value) || 0;
            if (received < total) {
                this.showToast('Insufficient payment amount', 'error');
                return;
            }
        }

        // Create transaction
        const transaction = {
            id: `TXN${Date.now()}`,
            invoiceNumber: this.currentInvoiceNumber,
            date: new Date().toISOString(),
            customer: {
                name: document.getElementById('customerName')?.value || 'Walk-in Customer',
                phone: document.getElementById('customerPhone')?.value || ''
            },
            items: [...this.cart],
            subtotal,
            gst: gstCalculation,
            total,
            paymentMethod,
            isIntrastate: this.isIntrastate
        };

        this.transactions.push(transaction);
        
        // Generate and show invoice
        this.generateInvoice(transaction);
        
        // Clear cart and increment invoice number
        this.cart = [];
        this.currentInvoiceNumber++;
        
        // Reset form
        this.resetForm();
        this.updateCartDisplay();
        this.updateInvoiceNumber();
        
        this.showToast('Payment processed successfully!');
    }

    // Invoice Generation
    generateInvoice(transaction) {
        const invoiceContent = `
            <div class="invoice-header">
                <h2>${this.businessInfo.name}</h2>
                <p>${this.businessInfo.address}</p>
                <p>${this.businessInfo.city}, ${this.businessInfo.state} - ${this.businessInfo.pincode}</p>
                <p>GSTIN: ${this.businessInfo.gstin} | Phone: ${this.businessInfo.phone}</p>
            </div>

            <div class="invoice-details">
                <div>
                    <strong>Invoice #:</strong> ${transaction.invoiceNumber}<br>
                    <strong>Date:</strong> ${new Date(transaction.date).toLocaleDateString('en-IN')}<br>
                    <strong>Time:</strong> ${new Date(transaction.date).toLocaleTimeString('en-IN')}
                </div>
                <div>
                    <strong>Customer:</strong> ${transaction.customer.name}<br>
                    ${transaction.customer.phone ? `<strong>Phone:</strong> ${transaction.customer.phone}<br>` : ''}
                    <strong>Payment:</strong> ${transaction.paymentMethod.toUpperCase()}
                </div>
            </div>

            <table class="invoice-table">
                <thead>
                    <tr>
                        <th>Item</th>
                        <th>Qty</th>
                        <th>Rate</th>
                        <th>GST%</th>
                        <th class="text-right">Amount</th>
                    </tr>
                </thead>
                <tbody>
                    ${transaction.items.map(item => `
                        <tr>
                            <td>${item.name}</td>
                            <td>${item.quantity} ${item.unit}</td>
                            <td>₹${item.price}</td>
                            <td>${item.gstRate}%</td>
                            <td class="text-right">₹${item.totalPrice.toFixed(2)}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>

            <div class="invoice-summary">
                <div class="summary-row">
                    <span>Subtotal:</span>
                    <span>₹${transaction.subtotal.toFixed(2)}</span>
                </div>
                ${transaction.isIntrastate ? `
                    <div class="summary-row">
                        <span>CGST:</span>
                        <span>₹${transaction.gst.cgst.toFixed(2)}</span>
                    </div>
                    <div class="summary-row">
                        <span>SGST:</span>
                        <span>₹${transaction.gst.sgst.toFixed(2)}</span>
                    </div>
                ` : `
                    <div class="summary-row">
                        <span>IGST:</span>
                        <span>₹${transaction.gst.igst.toFixed(2)}</span>
                    </div>
                `}
                <div class="summary-row total-row">
                    <span><strong>Total Amount:</strong></span>
                    <span><strong>₹${transaction.total.toFixed(2)}</strong></span>
                </div>
            </div>

            <div class="invoice-footer">
                <p>Thank you for shopping with us!</p>
                <p>This is a computer-generated invoice</p>
            </div>
        `;

        const invoiceContentEl = document.getElementById('invoiceContent');
        const invoiceModal = document.getElementById('invoiceModal');
        
        if (invoiceContentEl && invoiceModal) {
            invoiceContentEl.innerHTML = invoiceContent;
            invoiceModal.classList.remove('hidden');
        }
    }

    // Manual Product Addition
    openManualAddModal() {
        const modal = document.getElementById('manualAddModal');
        if (modal) {
            modal.classList.remove('hidden');
        }
    }

    addManualProduct() {
        const nameEl = document.getElementById('manualProductName');
        const priceEl = document.getElementById('manualProductPrice');
        const gstRateEl = document.getElementById('manualGstRate');
        const quantityEl = document.getElementById('manualQuantity');

        const name = nameEl?.value?.trim();
        const price = parseFloat(priceEl?.value) || 0;
        const gstRate = parseInt(gstRateEl?.value) || 18;
        const quantity = parseInt(quantityEl?.value) || 1;

        if (!name || !price || !quantity) {
            this.showToast('Please fill all fields', 'error');
            return;
        }

        const product = {
            id: `manual_${Date.now()}`,
            name,
            price,
            gstRate,
            stock: quantity,
            unit: 'pcs',
            image: '📦',
            category: 'Manual'
        };

        this.addToCart(product, quantity);
        
        const modal = document.getElementById('manualAddModal');
        if (modal) {
            modal.classList.add('hidden');
        }
        
        this.resetManualForm();
        this.showToast(`Added ${name} to cart`);
    }

    // Reports and Inventory
    showReports() {
        const today = new Date().toDateString();
        const todayTransactions = this.transactions.filter(t => 
            new Date(t.date).toDateString() === today
        );

        const totalSales = todayTransactions.reduce((sum, t) => sum + t.total, 0);
        const totalTransactions = todayTransactions.length;
        const avgTransaction = totalSales / totalTransactions || 0;

        const reportsContent = `
            <h3>Daily Sales Report - ${today}</h3>
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 24px;">
                <div style="padding: 16px; background: var(--color-bg-1); border-radius: 8px; text-align: center;">
                    <h4>Total Sales</h4>
                    <p style="font-size: 24px; font-weight: bold; color: var(--color-success);">₹${totalSales.toFixed(2)}</p>
                </div>
                <div style="padding: 16px; background: var(--color-bg-2); border-radius: 8px; text-align: center;">
                    <h4>Transactions</h4>
                    <p style="font-size: 24px; font-weight: bold; color: var(--color-primary);">${totalTransactions}</p>
                </div>
                <div style="padding: 16px; background: var(--color-bg-3); border-radius: 8px; text-align: center;">
                    <h4>Average Sale</h4>
                    <p style="font-size: 24px; font-weight: bold; color: var(--color-warning);">₹${avgTransaction.toFixed(2)}</p>
                </div>
            </div>
            
            <h4>Recent Transactions</h4>
            <table class="invoice-table">
                <thead>
                    <tr>
                        <th>Invoice</th>
                        <th>Customer</th>
                        <th>Amount</th>
                        <th>Payment</th>
                        <th>Time</th>
                    </tr>
                </thead>
                <tbody>
                    ${todayTransactions.slice(-10).map(t => `
                        <tr>
                            <td>${t.invoiceNumber}</td>
                            <td>${t.customer.name}</td>
                            <td>₹${t.total.toFixed(2)}</td>
                            <td>${t.paymentMethod.toUpperCase()}</td>
                            <td>${new Date(t.date).toLocaleTimeString('en-IN')}</td>
                        </tr>
                    `).join('') || '<tr><td colspan="5" style="text-align: center;">No transactions today</td></tr>'}
                </tbody>
            </table>
        `;

        const reportsContentEl = document.getElementById('reportsContent');
        const reportsModal = document.getElementById('reportsModal');
        
        if (reportsContentEl && reportsModal) {
            reportsContentEl.innerHTML = reportsContent;
            reportsModal.classList.remove('hidden');
        }
    }

    showInventory() {
        const inventoryContent = `
            <h3>Inventory Management</h3>
            <div style="margin-bottom: 16px;">
                <strong>Total Products:</strong> ${this.products.length} |
                <strong>Low Stock Items:</strong> ${this.products.filter(p => p.stock < 10).length}
            </div>
            
            <table class="invoice-table">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Category</th>
                        <th>Price</th>
                        <th>Stock</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    ${this.products.map(product => `
                        <tr>
                            <td>${product.image} ${product.name}</td>
                            <td>${product.category}</td>
                            <td>₹${product.price}</td>
                            <td>${product.stock}</td>
                            <td>
                                <span class="status ${product.stock === 0 ? 'status--error' : product.stock < 10 ? 'status--warning' : 'status--success'}">
                                    ${product.stock === 0 ? 'Out of Stock' : product.stock < 10 ? 'Low Stock' : 'In Stock'}
                                </span>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;

        const inventoryContentEl = document.getElementById('inventoryContent');
        const inventoryModal = document.getElementById('inventoryModal');
        
        if (inventoryContentEl && inventoryModal) {
            inventoryContentEl.innerHTML = inventoryContent;
            inventoryModal.classList.remove('hidden');
        }
    }

    showLastInvoice() {
        const lastTransaction = this.transactions[this.transactions.length - 1];
        if (lastTransaction) {
            this.generateInvoice(lastTransaction);
        } else {
            this.showToast('No previous invoices found', 'error');
        }
    }

    showDailySales() {
        this.showReports();
    }

    // Utility Functions
    resetForm() {
        const customerName = document.getElementById('customerName');
        const customerPhone = document.getElementById('customerPhone');
        const receivedAmount = document.getElementById('receivedAmount');
        const barcodeInput = document.getElementById('barcodeInput');

        if (customerName) customerName.value = '';
        if (customerPhone) customerPhone.value = '';
        if (receivedAmount) receivedAmount.value = '';
        if (barcodeInput) barcodeInput.focus();
    }

    resetManualForm() {
        const fields = [
            'manualProductName',
            'manualProductPrice'
        ];
        
        fields.forEach(fieldId => {
            const field = document.getElementById(fieldId);
            if (field) field.value = '';
        });
        
        const quantityField = document.getElementById('manualQuantity');
        if (quantityField) quantityField.value = '1';
    }

    updateInvoiceNumber() {
        const invoiceNumberEl = document.getElementById('invoiceNumber');
        if (invoiceNumberEl) {
            invoiceNumberEl.textContent = this.currentInvoiceNumber;
        }
    }

    holdBill() {
        if (this.cart.length === 0) return;
        
        this.showToast('Bill holding feature - Premium version only');
    }

    // Toast Notifications
    showToast(message, type = 'success') {
        const toast = document.getElementById('successToast');
        const toastMessage = document.getElementById('toastMessage');
        
        if (!toast || !toastMessage) return;
        
        toastMessage.textContent = message;
        toast.classList.remove('hidden');
        toast.classList.add('show');

        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => {
                toast.classList.add('hidden');
            }, 300);
        }, 3000);
    }
}

// Initialize POS System when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.pos = new POSSystem();
});